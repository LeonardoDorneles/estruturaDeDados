public class Main {
    public static void main(String[] args) {
        ListaDuplamenteEncadeada<Carro> listaCarros = new ListaDuplamenteEncadeada<>();
        listaCarros.inserir(new Carro("Toyota", "Corolla", 2020));
        listaCarros.inserir(new Carro("Volkswagen", "Gol", 2010));
        listaCarros.inserir(new Carro("Ford", "Mustang GT", 2024));

        System.out.println("Carros na lista (frente para trás):");
        listaCarros.imprimirParaFrente();

        System.out.println("----------------------------------------------------");
        
        System.out.println("\nCarros na lista (trás para frente):");
        listaCarros.imprimirParaTras();

        System.out.println("----------------------------------------------------");

        // Removendo um carro
        Carro carroRemover = new Carro("Volkswagen", "Gol", 2010);
        if (listaCarros.remover(carroRemover)) {
            System.out.println("\nCarro removido: " + carroRemover.toString());
        } else {
            System.out.println("\nCarro não encontrado para remoção.");
        }

        System.out.println("----------------------------------------------------");

        System.out.println("\nCarros na lista após remoção:");
        listaCarros.imprimirParaFrente();

        System.out.println("----------------------------------------------------");

        ListaDuplamenteEncadeada<Aluno> listaAlunos = new ListaDuplamenteEncadeada<>();
        listaAlunos.inserir(new Aluno("Leonardo Dorneles", 19, 1));
        listaAlunos.inserir(new Aluno("Raquel Mainard", 29, 10));
        listaAlunos.inserir(new Aluno("Miguel Arrojo", 18, 8));
        listaAlunos.inserir(new Aluno("Neymar Jr", 32, 6));
        listaAlunos.inserir(new Aluno("Yunk Vino", 23, 7));

        

        System.out.println("Alunos na lista (frente para trás):");
        listaAlunos.imprimirParaFrente();
        System.out.println("----------------------------------------------------");
        System.out.println("\nAlunos na lista (trás para frente):");
        listaAlunos.imprimirParaTras();
        System.out.println("----------------------------------------------------");
        // Removendo um aluno
        Aluno alunoRemover = new Aluno("Leonardo Dorneles", 19, 1);
        if (listaAlunos.remover(alunoRemover)) {
            System.out.println("\nAluno removido: " + alunoRemover.toString());
        } else {
            System.out.println("\nAluno não encontrado para remoção.");
        }

        System.out.println("\nAlunos na lista após remoção:");
        listaAlunos.imprimirParaFrente();
    }
}