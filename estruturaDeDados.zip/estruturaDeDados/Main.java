import java.util.List;

public class Main {
    public static void main(String[] args) {
        VetorAlunos alunos = new VetorAlunos(3);
        alunos.adiciona(new Aluno("Ana Julia Schott", 19, 9));
        alunos.adiciona(new Aluno("Raquel Mainardi", 29, 10));
        alunos.adiciona(new Aluno("Miguel Arrojo", 18, 8));
        alunos.adiciona(new Aluno("Leonardo Dorneles", 19, 7));
        alunos.adiciona(new Aluno("Neymar jr", 32, 4));
        alunos.adiciona(new Aluno("Yunk Vino", 23,5));
        

        System.out.println("Tamanho do vetor de alunos: " + alunos.tamanho());
        System.out.println("--------------------------------------");

        List<Aluno> alunosNotaMenorQue6 = alunos.contemAlunoNotaMenorQue(6.0);
        List<Aluno> alunosNotaMaiorOuIgualA6 = alunos.contemAlunoNotaMaiorOuIgualA(6.0);

        if (!alunosNotaMenorQue6.isEmpty()) {
            System.out.println("Alunos com nota menor que 6:");
            for (Aluno aluno : alunosNotaMenorQue6) {
                System.out.println("Nome: " + aluno.getNome() + ", Nota: " + aluno.getNota());
            }
            System.out.println("--------------------------------------");
        } else {
            System.out.println("Nenhum aluno com nota menor que 6 encontrado.");
            System.out.println("--------------------------------------");
        }

        if (!alunosNotaMaiorOuIgualA6.isEmpty()) {
            System.out.println("Alunos com nota maior ou igual a 6:");
            for (Aluno aluno : alunosNotaMaiorOuIgualA6) {
                System.out.println("Nome: " + aluno.getNome() + ", Nota: " + aluno.getNota());
            }
        } else {
            System.out.println("Nenhum aluno com nota maior ou igual a 6 encontrado.");
        }
    }
}
